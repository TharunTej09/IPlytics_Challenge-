package com.example.batchprocessing.config;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.item.database.BeanPropertyItemSqlParameterSourceProvider;
import org.springframework.batch.item.database.JdbcBatchItemWriter;
import org.springframework.batch.item.database.builder.JdbcBatchItemWriterBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.example.batchprocessing.listener.DeclarationJobCompletionNotificationListener;
import com.example.batchprocessing.listener.PatentJobCompletionNotificationListener;
import com.example.batchprocessing.listener.StandardJobCompletionNotificationListener;
import com.example.batchprocessing.mapper.DeclarationFieldSetMapper;
import com.example.batchprocessing.mapper.PatentFieldSetMapper;
import com.example.batchprocessing.mapper.StandardFieldSetMapper;
import com.example.batchprocessing.model.Declaration;
import com.example.batchprocessing.model.Patent;
import com.example.batchprocessing.model.Standard;
import com.example.batchprocessing.processor.DeclarationItemProcessor;
import com.example.batchprocessing.processor.PatentItemProcessor;
import com.example.batchprocessing.processor.StandardItemProcessor;

// tag::setup[]
@Configuration
@EnableBatchProcessing
public class BatchConfiguration {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;
	// end::setup[]
	
	@Autowired
	public DataSource dataSource;
	
	@Bean
	@Primary
    @ConfigurationProperties(prefix = "spring.primary.datasource")
	 public DataSource dataSource() {
	  final DriverManagerDataSource dataSource = new DriverManagerDataSource();
	  dataSource.setDriverClassName("com.mysql.jdbc.Driver");
	  dataSource.setUrl("jdbc:mysql://localhost:3306/tarun_project?characterEncoding=latin1&useSSL=false");
	  dataSource.setUsername("root");
	  dataSource.setPassword("root");
	  
	  return dataSource;
	 }

	// tag::readerwriterprocessor[]
	
	@Bean
	public FlatFileItemReader<Patent> patentReader() {
		FlatFileItemReader<Patent> flatFileItemReaderBuilder = new FlatFileItemReaderBuilder<Patent>()
			.name("patentItemReader")
			.resource(new ClassPathResource("patents.csv"))
			.delimited()
			.names(new String[]{
					"title", 
					"publicationNr", 
					"inpadocFamilyId", 
					"applicant", 
					"patentOffice", 
					"inventor",
					"publicationDate",
					"kindType",
					"granted",
					"lapsed",
					"patentCitation",
					"familySize",
					"marketCoverage",
					"technicalRelevance"})
			.fieldSetMapper(new PatentFieldSetMapper())
			.build();
		return flatFileItemReaderBuilder;
	}
	
	@Bean
	public PatentItemProcessor patentProcessor() {
		return new PatentItemProcessor();
	}
	
	@Bean
	public JdbcBatchItemWriter<Patent> patentWriter(DataSource dataSource) {
		JdbcBatchItemWriter<Patent> jdbcBatchItemWriter = new JdbcBatchItemWriterBuilder<Patent>()
			.itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
			.sql("INSERT INTO patents ("
					
					+ "title, "
					+ "publication_nr, "
					+ "inpadoc_family_id, "
					+ "applicant, "
					+ "patent_office, "
					+ "inventor, "
					+ "publication_date, "
					+ "kind_type, "
					+ "granted, "
					+ "lapsed, "
					+ "patent_citation, "
					+ "family_size, "
					+ "market_coverage, "
					+ "technical_relevance"
					
					+ ") VALUES ("
					
					+ ":title,"
					+ ":publicationNr,"
					+ ":inpadocFamilyId," 
					+ ":applicant,"
					+ ":patentOffice,"
					+ ":inventor,"
					+ ":publicationDate,"
					+ ":kindType,"
					+ ":granted,"
					+ ":lapsed,"
					+ ":patentCitation,"
					+ ":familySize,"
					+ ":marketCoverage,"
					+ ":technicalRelevance"
					
					+ ")")
			.dataSource(dataSource)    
			.build();
		return jdbcBatchItemWriter;
	}
	
	@Bean
	public FlatFileItemReader<Standard> standardReader() {
		FlatFileItemReader<Standard> flatFileItemReaderBuilder = new FlatFileItemReaderBuilder<Standard>()
			.name("standardItemReader")
			.resource(new ClassPathResource("standards.csv"))
			.delimited()
			.names(new String[]{
					"title", 
					"standardDocumentId", 
					"technologyGeneration", 
					"publicationDate", 
					"standardSettingOrganization", 
					"author",
					"standardProject",
					"versionHistory",
					"originalDocument"
					})
			.fieldSetMapper(new StandardFieldSetMapper())
			.build();
		return flatFileItemReaderBuilder;
	}
	
	@Bean
	public StandardItemProcessor standardProcessor() {
		return new StandardItemProcessor();
	}
	
	@Bean
	public JdbcBatchItemWriter<Standard> standardWriter(DataSource dataSource) {
		JdbcBatchItemWriter<Standard> jdbcBatchItemWriter = new JdbcBatchItemWriterBuilder<Standard>()
			.itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
			.sql("INSERT INTO standards ("
					
					+ "title,"
					+ "standard_document_id,"
					+ "technology_generation,"
					+ "publication_date,"
					+ "standard_setting_organization,"
					+ "author,"
					+ "standard_project,"
					+ "version_history,"
					+ "original_document"
					
					+ ") VALUES ("
					
					+ ":title,"
					+ ":standardDocumentId,"
					+ ":technologyGeneration,"
					+ ":publicationDate,"
					+ ":standardSettingOrganization,"
					+ ":author,"
					+ ":standardProject,"
					+ ":versionHistory,"
					+ ":originalDocument"
					
					+ ")")
			.dataSource(dataSource)
			.build();
		return jdbcBatchItemWriter;
	}
	
	@Bean
	public FlatFileItemReader<Declaration> declarationReader() {
		FlatFileItemReader<Declaration> flatFileItemReaderBuilder = new FlatFileItemReaderBuilder<Declaration>()
			.name("declarationItemReader")
			.resource(new ClassPathResource("declarations.csv"))
			.delimited()
			.names(new String[]{
					"declaringCompany", 
					"declarationDate", 
					"standardProject", 
					"standardDocumentId", 
					"technologyGeneration", 
					"releases",
					"publicationNr",
					"applicationNr"
					})
			.fieldSetMapper(new DeclarationFieldSetMapper())
			.build();
		return flatFileItemReaderBuilder;
	}
	
	@Bean
	public DeclarationItemProcessor declarationProcessor() {
		return new DeclarationItemProcessor();
	}
	
	@Bean
	public JdbcBatchItemWriter<Declaration> declarationWriter(DataSource dataSource) {
		JdbcBatchItemWriter<Declaration> jdbcBatchItemWriter = new JdbcBatchItemWriterBuilder<Declaration>()
			.itemSqlParameterSourceProvider(new BeanPropertyItemSqlParameterSourceProvider<>())
			.sql("INSERT INTO declarations ("
					
					+ "declaring_company,"
					+ "declaration_date,"
					+ "standard_project,"
					+ "standard_document_id,"
					+ "technology_generation,"
					+ "releases,"
					+ "publication_nr,"
					+ "application_nr"
					
					+ ") VALUES ("
					
					+ ":declaringCompany,"
					+ ":declarationDate,"
					+ ":standardProject,"
					+ ":standardDocumentId,"
					+ ":technologyGeneration,"
					+ ":releases,"
					+ ":publicationNr,"
					+ ":applicationNr"
					
					+ ")")
			.dataSource(dataSource)
			.build();
		return jdbcBatchItemWriter;
	}
	
	// end::readerwriterprocessor[]

	// tag::jobstep[]

	
	@Bean
	public Step patentStep(JdbcBatchItemWriter<Patent> patentWriter) {
		return stepBuilderFactory.get("patentStep")
			.<Patent, Patent> chunk(1000)
			.reader(patentReader())
			.processor(patentProcessor())
			.writer(patentWriter)
			.build();
	}
	
	@Bean
	public Step standardStep(JdbcBatchItemWriter<Standard> standardWriter) {
		return stepBuilderFactory.get("standardStep")
			.<Standard, Standard> chunk(1000)
			.reader(standardReader())
			.processor(standardProcessor())
			.writer(standardWriter)
			.build();
	}
	
	@Bean
	public Step declarationStep(JdbcBatchItemWriter<Declaration> declarationWriter) {
		return stepBuilderFactory.get("standardStep")
			.<Declaration, Declaration> chunk(1000)
			.reader(declarationReader())
			.processor(declarationProcessor())
			.writer(declarationWriter)
			.build();
	}
	
	
	// end::jobstep[]
	
	// tag: run job
	
	@Bean
	public Job importPatentJob(PatentJobCompletionNotificationListener listener, Step patentStep) {
		return jobBuilderFactory.get("importPatentJob")
			.listener(listener)
			.flow(patentStep)
			.end()
			.build();
	}
	
	@Bean
	public Job importStandardJob(StandardJobCompletionNotificationListener listener, Step standardStep) {
		return jobBuilderFactory.get("importStandardJob")
			.listener(listener)
			.flow(standardStep)
			.end()
			.build();
	}
	
	@Bean
	public Job importDeclarationJob(DeclarationJobCompletionNotificationListener listener, Step declarationStep) {
		return jobBuilderFactory.get("importDeclarationJob")
			.listener(listener)
			.flow(declarationStep)
			.end()
			.build();
	}
	// end::runJob
}
