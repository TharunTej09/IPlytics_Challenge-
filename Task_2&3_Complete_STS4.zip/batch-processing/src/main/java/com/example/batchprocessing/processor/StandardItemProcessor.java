package com.example.batchprocessing.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import com.example.batchprocessing.model.Standard;

public class StandardItemProcessor  implements ItemProcessor<Standard, Standard> {

	private static final Logger log = LoggerFactory.getLogger(PatentItemProcessor.class);

	@Override
	public Standard process(final Standard standard) throws Exception {

		log.info(standard.toString());

		return standard;
	}
}
