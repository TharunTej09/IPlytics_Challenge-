package com.example.batchprocessing.mapper;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import com.example.batchprocessing.model.Declaration;

public class DeclarationFieldSetMapper implements FieldSetMapper<Declaration> {
	@Override
	public Declaration mapFieldSet(FieldSet fieldSet) throws BindException {
		Declaration declaration = null;
		System.out.println(fieldSet.readRawString(1));
		try {
			declaration = new Declaration(
					fieldSet.readRawString(0), 
					new SimpleDateFormat("yyyy-MM-dd").parse(fieldSet.readRawString(1)), 
					fieldSet.readRawString(2), 
					fieldSet.readRawString(3), 
					fieldSet.readRawString(4), 
					fieldSet.readRawString(5), 
					fieldSet.readRawString(6), 
					fieldSet.readRawString(7));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return declaration;
	}
}
