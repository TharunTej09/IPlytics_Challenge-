package com.example.batchprocessing.mapper;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import com.example.batchprocessing.model.Patent;

public class PatentFieldSetMapper  implements FieldSetMapper<Patent> {
	@Override
	public Patent mapFieldSet(FieldSet fieldSet) throws BindException {
		Patent patent = new Patent();
		patent.setTitle(fieldSet.readRawString(0));
		patent.setPublicationNr(fieldSet.readRawString(1));
		patent.setInpadocFamilyId(fieldSet.readRawString(2));
		patent.setApplicant(fieldSet.readRawString(3));
		patent.setPatentOffice(fieldSet.readRawString(4));
		patent.setInventor(fieldSet.readRawString(5));
		try {
			patent.setPublicationDate(new SimpleDateFormat("yyyy-MM-dd").parse(fieldSet.readRawString(6)));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		patent.setKindType(fieldSet.readRawString(7));
		patent.setGranted(new Boolean(fieldSet.readRawString(8)));
		patent.setLapsed(new Boolean(fieldSet.readRawString(9)));
		patent.setPatentCitation(fieldSet.readRawString(10));
		patent.setFamilySize(Integer.parseInt(fieldSet.readRawString(11)));
		patent.setMarketCoverage(Double.parseDouble(fieldSet.readRawString(12)));
		patent.setTechnicalRelevance(Double.parseDouble(fieldSet.readRawString(13)));
		
		return patent;
	}
}
