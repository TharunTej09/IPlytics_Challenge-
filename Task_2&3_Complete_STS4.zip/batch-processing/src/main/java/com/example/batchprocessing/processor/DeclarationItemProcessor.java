package com.example.batchprocessing.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import com.example.batchprocessing.model.Declaration;

public class DeclarationItemProcessor   implements ItemProcessor<Declaration, Declaration> {

	private static final Logger log = LoggerFactory.getLogger(DeclarationItemProcessor.class);

	@Override
	public Declaration process(final Declaration declaration) throws Exception {

		log.info(declaration.toString());

		return declaration;
	}
}
