package com.example.batchprocessing.mapper;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

import com.example.batchprocessing.model.Standard;

public class StandardFieldSetMapper implements FieldSetMapper<Standard> {
	@Override
	public Standard mapFieldSet(FieldSet fieldSet) throws BindException {
		Standard standard = null;
		try {
			standard = new Standard(
					fieldSet.readRawString(1),
					fieldSet.readRawString(0),
					fieldSet.readRawString(2),
					new SimpleDateFormat("dd-MM-yyyy").parse(fieldSet.readRawString(3)),
					fieldSet.readRawString(4),
					fieldSet.readRawString(5),
					fieldSet.readRawString(6),
					fieldSet.readRawString(7),
					fieldSet.readRawString(8));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return standard;
	}
}
