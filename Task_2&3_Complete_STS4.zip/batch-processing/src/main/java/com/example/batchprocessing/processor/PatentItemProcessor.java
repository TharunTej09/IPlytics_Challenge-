package com.example.batchprocessing.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import com.example.batchprocessing.model.Patent;

public class PatentItemProcessor implements ItemProcessor<Patent, Patent> {

	private static final Logger log = LoggerFactory.getLogger(PatentItemProcessor.class);

	@Override
	public Patent process(final Patent patent) throws Exception {

		log.info(patent.toString());

		return patent;
	}
}
