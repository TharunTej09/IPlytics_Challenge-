package com.example.batchprocessing.model;

import java.util.Date;

public class Declaration {
	
	private String declaringCompany;
	private Date declarationDate;
	private String standardProject;
	private String standardDocumentId;
	private String technologyGeneration;
	private String releases;
	private String publicationNr;
	private String applicationNr;

	public Declaration() {
	}

	public String getDeclaringCompany() {
		return declaringCompany;
	}

	public void setDeclaringCompany(String declaringCompany) {
		this.declaringCompany = declaringCompany;
	}

	public Date getDeclarationDate() {
		return declarationDate;
	}

	public void setDeclarationDate(Date declarationDate) {
		this.declarationDate = declarationDate;
	}

	public String getStandardProject() {
		return standardProject;
	}

	public void setStandardProject(String standardProject) {
		this.standardProject = standardProject;
	}

	public String getStandardDocumentId() {
		return standardDocumentId;
	}

	public void setStandardDocumentId(String standardDocumentId) {
		this.standardDocumentId = standardDocumentId;
	}

	public String getTechnologyGeneration() {
		return technologyGeneration;
	}

	public void setTechnologyGeneration(String technologyGeneration) {
		this.technologyGeneration = technologyGeneration;
	}

	public String getReleases() {
		return releases;
	}

	public void setReleases(String releases) {
		this.releases = releases;
	}

	public String getPublicationNr() {
		return publicationNr;
	}

	public void setPublicationNr(String publicationNr) {
		this.publicationNr = publicationNr;
	}

	public String getApplicationNr() {
		return applicationNr;
	}

	public void setApplicationNr(String applicationNr) {
		this.applicationNr = applicationNr;
	}

	@Override
	public String toString() {
		return "Declaration [declaringCompany=" + declaringCompany + ", declarationDate=" + declarationDate
				+ ", standardProject=" + standardProject + ", standardDocumentId=" + standardDocumentId
				+ ", technologyGeneration=" + technologyGeneration + ", releases=" + releases + ", publicationNr="
				+ publicationNr + ", applicationNr=" + applicationNr + "]";
	}

	public Declaration(String declaringCompany, Date declarationDate, String standardProject, String standardDocumentId,
			String technologyGeneration, String releases, String publicationNr, String applicationNr) {
		super();
		this.declaringCompany = declaringCompany;
		this.declarationDate = declarationDate;
		this.standardProject = standardProject;
		this.standardDocumentId = standardDocumentId;
		this.technologyGeneration = technologyGeneration;
		this.releases = releases;
		this.publicationNr = publicationNr;
		this.applicationNr = applicationNr;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((applicationNr == null) ? 0 : applicationNr.hashCode());
		result = prime * result + ((declarationDate == null) ? 0 : declarationDate.hashCode());
		result = prime * result + ((declaringCompany == null) ? 0 : declaringCompany.hashCode());
		result = prime * result + ((publicationNr == null) ? 0 : publicationNr.hashCode());
		result = prime * result + ((releases == null) ? 0 : releases.hashCode());
		result = prime * result + ((standardDocumentId == null) ? 0 : standardDocumentId.hashCode());
		result = prime * result + ((standardProject == null) ? 0 : standardProject.hashCode());
		result = prime * result + ((technologyGeneration == null) ? 0 : technologyGeneration.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Declaration other = (Declaration) obj;
		if (applicationNr == null) {
			if (other.applicationNr != null)
				return false;
		} else if (!applicationNr.equals(other.applicationNr))
			return false;
		if (declarationDate == null) {
			if (other.declarationDate != null)
				return false;
		} else if (!declarationDate.equals(other.declarationDate))
			return false;
		if (declaringCompany == null) {
			if (other.declaringCompany != null)
				return false;
		} else if (!declaringCompany.equals(other.declaringCompany))
			return false;
		if (publicationNr == null) {
			if (other.publicationNr != null)
				return false;
		} else if (!publicationNr.equals(other.publicationNr))
			return false;
		if (releases == null) {
			if (other.releases != null)
				return false;
		} else if (!releases.equals(other.releases))
			return false;
		if (standardDocumentId == null) {
			if (other.standardDocumentId != null)
				return false;
		} else if (!standardDocumentId.equals(other.standardDocumentId))
			return false;
		if (standardProject == null) {
			if (other.standardProject != null)
				return false;
		} else if (!standardProject.equals(other.standardProject))
			return false;
		if (technologyGeneration == null) {
			if (other.technologyGeneration != null)
				return false;
		} else if (!technologyGeneration.equals(other.technologyGeneration))
			return false;
		return true;
	}

	

}
