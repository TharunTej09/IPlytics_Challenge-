package com.example.batchprocessing.model;

import java.util.Date;

public class Patent {

	private String title;
	private String publicationNr;
	private String inpadocFamilyId;
	private String applicant;
	private String patentOffice;
	private String inventor;
	private Date publicationDate;
	private String kindType;
	private String patentCitation;
	private boolean granted;
	private boolean lapsed;
	private int familySize;
	private double marketCoverage;
	private double technicalRelevance;

	public Patent() {
	}

	public Patent(String title, String publicationNr, String inpadocFamilyId, String applicant, String patentOffice,
			String inventor, Date publicationDate, String kindType, String patentCitation, boolean granted,
			boolean lapsed, int familySize, double marketCoverage, double technicalRelevance) {
		this.title = title;
		this.publicationNr = publicationNr;
		this.inpadocFamilyId = inpadocFamilyId;
		this.applicant = applicant;
		this.patentOffice = patentOffice;
		this.inventor = inventor;
		this.publicationDate = publicationDate;
		this.kindType = kindType;
		this.patentCitation = patentCitation;
		this.granted = granted;
		this.lapsed = lapsed;
		this.familySize = familySize;
		this.marketCoverage = marketCoverage;
		this.technicalRelevance = technicalRelevance;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getPublicationNr() {
		return publicationNr;
	}

	public void setPublicationNr(String publicationNr) {
		this.publicationNr = publicationNr;
	}

	public String getInpadocFamilyId() {
		return inpadocFamilyId;
	}

	public void setInpadocFamilyId(String inpadocFamilyId) {
		this.inpadocFamilyId = inpadocFamilyId;
	}

	public String getApplicant() {
		return applicant;
	}

	public void setApplicant(String applicant) {
		this.applicant = applicant;
	}

	public String getPatentOffice() {
		return patentOffice;
	}

	public void setPatentOffice(String patentOffice) {
		this.patentOffice = patentOffice;
	}

	public String getInventor() {
		return inventor;
	}

	public void setInventor(String inventor) {
		this.inventor = inventor;
	}

	public Date getPublicationDate() {
		return publicationDate;
	}

	public void setPublicationDate(Date publicationDate) {
		this.publicationDate = publicationDate;
	}

	public String getKindType() {
		return kindType;
	}

	public void setKindType(String kindType) {
		this.kindType = kindType;
	}

	public String getPatentCitation() {
		return patentCitation;
	}

	public void setPatentCitation(String patentCitation) {
		this.patentCitation = patentCitation;
	}

	public boolean isGranted() {
		return granted;
	}

	public void setGranted(boolean granted) {
		this.granted = granted;
	}

	public boolean isLapsed() {
		return lapsed;
	}

	public void setLapsed(boolean lapsed) {
		this.lapsed = lapsed;
	}

	public int getFamilySize() {
		return familySize;
	}

	public void setFamilySize(int familySize) {
		this.familySize = familySize;
	}

	public double getMarketCoverage() {
		return marketCoverage;
	}

	public void setMarketCoverage(double marketCoverage) {
		this.marketCoverage = marketCoverage;
	}

	public double getTechnicalRelevance() {
		return technicalRelevance;
	}

	public void setTechnicalRelevance(double technicalRelevance) {
		this.technicalRelevance = technicalRelevance;
	}

	@Override
	public String toString() {
		return "Patent [title=" + title + ", publicationNr=" + publicationNr + ", inpadocFamilyId=" + inpadocFamilyId
				+ ", applicant=" + applicant + ", patentOffice=" + patentOffice + ", inventor=" + inventor
				+ ", publicationDate=" + publicationDate + ", kindType=" + kindType + ", patentCitation="
				+ patentCitation + ", granted=" + granted + ", lapsed=" + lapsed + ", familySize=" + familySize
				+ ", marketCoverage=" + marketCoverage + ", technicalRelevance=" + technicalRelevance + "]";
	}

	
}
