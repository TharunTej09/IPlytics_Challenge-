package com.example.batchprocessing.model;

import java.util.Date;

public class Standard {

	private String standardDocumentId;
	private String title;
	private String technologyGeneration;
	private Date publicationDate;
	private String standardSettingOrganization;
	private String author;
	private String standardProject;
	private String versionHistory;
	private String originalDocument;
	
	public Standard() {
	}

	public String getStandardDocumentId() {
		return standardDocumentId;
	}

	public void setStandardDocumentId(String standardDocumentId) {
		this.standardDocumentId = standardDocumentId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTechnologyGeneration() {
		return technologyGeneration;
	}

	public void setTechnologyGeneration(String technologyGeneration) {
		this.technologyGeneration = technologyGeneration;
	}

	public Date getPublicationDate() {
		return publicationDate;
	}

	public void setPublicationDate(Date publicationDate) {
		this.publicationDate = publicationDate;
	}

	public String getStandardSettingOrganization() {
		return standardSettingOrganization;
	}

	public void setStandardSettingOrganization(String standardSettingOrganization) {
		this.standardSettingOrganization = standardSettingOrganization;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getStandardProject() {
		return standardProject;
	}

	public void setStandardProject(String standardProject) {
		this.standardProject = standardProject;
	}

	public String getVersionHistory() {
		return versionHistory;
	}

	public void setVersionHistory(String versionHistory) {
		this.versionHistory = versionHistory;
	}

	public String getOriginalDocument() {
		return originalDocument;
	}

	public void setOriginalDocument(String originalDocument) {
		this.originalDocument = originalDocument;
	}

	public Standard(String standardDocumentId, String title, String technologyGeneration, Date publicationDate,
			String standardSettingOrganization, String author, String standardProject, String versionHistory,
			String originalDocument) {
		super();
		this.standardDocumentId = standardDocumentId;
		this.title = title;
		this.technologyGeneration = technologyGeneration;
		this.publicationDate = publicationDate;
		this.standardSettingOrganization = standardSettingOrganization;
		this.author = author;
		this.standardProject = standardProject;
		this.versionHistory = versionHistory;
		this.originalDocument = originalDocument;
	}

	@Override
	public String toString() {
		return "Standard [standardDocumentId=" + standardDocumentId + ", title=" + title + ", technologyGeneration="
				+ technologyGeneration + ", publicationDate=" + publicationDate + ", standardSettingOrganization="
				+ standardSettingOrganization + ", author=" + author + ", standardProject=" + standardProject
				+ ", versionHistory=" + versionHistory + ", originalDocument=" + originalDocument + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((author == null) ? 0 : author.hashCode());
		result = prime * result + ((originalDocument == null) ? 0 : originalDocument.hashCode());
		result = prime * result + ((publicationDate == null) ? 0 : publicationDate.hashCode());
		result = prime * result + ((standardDocumentId == null) ? 0 : standardDocumentId.hashCode());
		result = prime * result + ((standardProject == null) ? 0 : standardProject.hashCode());
		result = prime * result + ((standardSettingOrganization == null) ? 0 : standardSettingOrganization.hashCode());
		result = prime * result + ((technologyGeneration == null) ? 0 : technologyGeneration.hashCode());
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		result = prime * result + ((versionHistory == null) ? 0 : versionHistory.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Standard other = (Standard) obj;
		if (author == null) {
			if (other.author != null)
				return false;
		} else if (!author.equals(other.author))
			return false;
		if (originalDocument == null) {
			if (other.originalDocument != null)
				return false;
		} else if (!originalDocument.equals(other.originalDocument))
			return false;
		if (publicationDate == null) {
			if (other.publicationDate != null)
				return false;
		} else if (!publicationDate.equals(other.publicationDate))
			return false;
		if (standardDocumentId == null) {
			if (other.standardDocumentId != null)
				return false;
		} else if (!standardDocumentId.equals(other.standardDocumentId))
			return false;
		if (standardProject == null) {
			if (other.standardProject != null)
				return false;
		} else if (!standardProject.equals(other.standardProject))
			return false;
		if (standardSettingOrganization == null) {
			if (other.standardSettingOrganization != null)
				return false;
		} else if (!standardSettingOrganization.equals(other.standardSettingOrganization))
			return false;
		if (technologyGeneration == null) {
			if (other.technologyGeneration != null)
				return false;
		} else if (!technologyGeneration.equals(other.technologyGeneration))
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		if (versionHistory == null) {
			if (other.versionHistory != null)
				return false;
		} else if (!versionHistory.equals(other.versionHistory))
			return false;
		return true;
	}
	
	
}
