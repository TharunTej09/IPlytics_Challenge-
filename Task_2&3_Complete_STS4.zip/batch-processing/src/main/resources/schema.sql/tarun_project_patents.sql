DROP TABLE IF EXISTS `patents`;
CREATE TABLE `patents` (
  `publication_nr` varchar(45) NOT NULL,
  `title` varchar(500) DEFAULT NULL,
  `inpadoc_family_id` varchar(45) DEFAULT NULL,
  `applicant` varchar(100) DEFAULT NULL,
  `patent_office` varchar(100) DEFAULT NULL,
  `inventor` varchar(100) DEFAULT NULL,
  `publication_date` date DEFAULT ((curdate() + interval 1 year)),
  `kind_type` varchar(45) DEFAULT NULL,
  `granted` tinyint(1) DEFAULT NULL,
  `lapsed` tinyint(1) DEFAULT NULL,
  `patent_citation` varchar(255) DEFAULT NULL,
  `family_size` int(11) DEFAULT NULL,
  `market_coverage` float DEFAULT NULL,
  `technical_relevance` float DEFAULT NULL,
  PRIMARY KEY (`publication_nr`),
  UNIQUE KEY `publication_nr_UNIQUE` (`publication_nr`)
)