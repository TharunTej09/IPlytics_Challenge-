DROP TABLE IF EXISTS `standards`;
CREATE TABLE `standards` (
  `standard_document_id` varchar(45) NOT NULL,
  `title` varchar(500) DEFAULT NULL,
  `technology_generation` varchar(100) DEFAULT NULL,
  `publication_date` date DEFAULT NULL,
  `standard_setting_organization` varchar(100) DEFAULT NULL,
  `author` varchar(45) DEFAULT NULL,
  `standard_project` varchar(100) DEFAULT NULL,
  `version_history` varchar(45) DEFAULT NULL,
  `original_document` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`standard_document_id`),
  UNIQUE KEY `standard_document_id_UNIQUE` (`standard_document_id`)
)