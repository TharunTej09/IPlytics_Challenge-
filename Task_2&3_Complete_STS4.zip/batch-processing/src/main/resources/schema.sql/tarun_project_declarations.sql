
DROP TABLE IF EXISTS `declarations`;
CREATE TABLE `declarations` (
  `declaring_company` varchar(100) DEFAULT NULL,
  `declaration_date` date DEFAULT NULL,
  `standard_project` varchar(45) DEFAULT NULL,
  `standard_document_id` varchar(45) DEFAULT NULL,
  `technology_generation` varchar(45) DEFAULT NULL,
  `releases` varchar(200) DEFAULT NULL,
  `publication_nr` varchar(45) DEFAULT NULL,
  `application_nr` varchar(45) DEFAULT NULL
)
